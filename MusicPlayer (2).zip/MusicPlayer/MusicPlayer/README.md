# MusicPlayer
This is the music player with the interactive UI for the easy access for user
This application can be used to play mp3 songs. The key features in this are as follows,
* It contains the ability to fetch all the mp3 songs from the Local Storage. 
* User can create his/her favourites playlist.
* Favourites playlist will be permanent until user deletes the songs.
* User can also add some songs to the currently playing song list which will be temporary.
* It also has search functionality which will the search the song and give the desired result.
* It contains a interactive UI which allows user to control the songs. 
These features are implemented with the help of :-
1. Navigation Drawer
2. Fragments
3. Viewpager
4. SQLite Database
5. Adapters.
